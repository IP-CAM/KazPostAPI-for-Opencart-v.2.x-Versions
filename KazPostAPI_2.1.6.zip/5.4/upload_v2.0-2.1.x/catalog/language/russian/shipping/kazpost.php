<?php
// Text
$_['text_title']       = 'Доставка Казпочтой';
$_['text_description'] = 'Казпочта ';

// Error
$_['error_destination_city']    = '<span style="color: red;">Уточните город</span>';